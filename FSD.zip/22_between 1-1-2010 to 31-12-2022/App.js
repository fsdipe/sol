const express = require('express');
const mongoose = require('mongoose');

const app = express();

// Connect to MongoDB (Make sure you have MongoDB running locally or provide a remote URI)
mongoose.connect('mongodb://localhost:27017/detailsDB', {
    useNewUrlParser: true,
    useUnifiedTopology: true
});

// Define the schema and model for the "details" collection
const detailsSchema = new mongoose.Schema({
    name: {
        type: String,
        trim: true,
        minlength: 3,
        maxlength: 12,
        uppercase: true,
        required: true
    },
    email: {
        type: String,
        required: true,
        validate: {
            validator: function(email) {
                // Regular expression for basic email validation
                return /^[\w-]+(\.[\w-]+)*@([\w-]+\.)+[a-zA-Z]{2,7}$/.test(email);
            },
            message: 'Invalid email format'
        }
    },
    dateOfJoining: {
        type: Date,
        required: true,
        min: '2010-01-01',
        max: '2022-12-31'
    }
});

const Detail = mongoose.model('Detail', detailsSchema);

app.use(express.urlencoded({ extended: true }));
app.use(express.static('public'));

app.get('/', (req, res) => {
    res.sendFile(__dirname + '/public/form.html');
});

app.post('/submit', async (req, res) => {
    try {
       const { name, email, dateOfJoining } = req.body;
       const newDetail = new Detail({
            name,
            email,
            dateOfJoining
        });
        await newDetail.save();
        res.send('Data saved successfully!');
    } catch (error) {
        res.status(400).send('Error: ' + error.message);
    }
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`);
});

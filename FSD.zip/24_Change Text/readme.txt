npx create-react-app myapp

src/
├──|index.js
├── 

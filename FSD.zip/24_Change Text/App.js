import React, { Component } from 'react';
import './App.css';

class App extends Component {
  constructor() {
    super();
    this.state = {
      text: 'Hello',
      textColor: 'red',
      isHidden: false,
    };
  }

  handleToggleText = () => {
    this.setState((prevState) => ({
      text: prevState.text === 'Hello' ? 'Welcome' : 'Hello',
    }));
  };

  handleToggleColor = () => {
    this.setState((prevState) => ({
      textColor: prevState.textColor === 'red' ? 'blue' : 'red',
    }));
  };

  handleToggleVisibility = () => {
    this.setState((prevState) => ({
      isHidden: !prevState.isHidden,
    }));
  };

  render() {
    const { text, textColor, isHidden } = this.state;

    return (
      <div className="App">
        <h1 style={{ color: textColor }}>{text}</h1>
        {!isHidden && <h2>Good Morning</h2>}
        <button onClick={this.handleToggleText}>Change Text</button>
        <button onClick={this.handleToggleColor}>Change Color</button>
        <button onClick={this.handleToggleVisibility}>
          {isHidden ? 'Show' : 'Hide'}
        </button>
      </div>
    );
  }
}

export default App;

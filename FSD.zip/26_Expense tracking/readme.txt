npx create-react-app app
src  replace app.js 

npm start

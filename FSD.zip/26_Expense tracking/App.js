import React, { useState } from 'react';

const ExpenseTracker = () => {
  // Initialize state to manage expenses and form input
  const [expenses, setExpenses] = useState([]);
  const [newExpense, setNewExpense] = useState({
    name: '',
    amount: '',
    category: '',
    date: '',
  });
  const [error, setError] = useState(null);

  // Function to handle form input changes
  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setNewExpense({
      ...newExpense,
      [name]: value,
    });
  };

  // Function to handle adding a new expense
  const handleAddExpense = () => {
    if (!newExpense.name || !newExpense.amount || !newExpense.date) {
      setError('Please fill in all required fields.');
      return;
    }

    setExpenses([...expenses, newExpense]);
    setNewExpense({
      name: '',
      amount: '',
      category: '',
      date: '',
    });
    setError(null);
  };

  return (
    <div>
      <h1>Expense Tracker</h1>
      
      {error && <p className="error">{error}</p>}

      {/* Expense Input Form */}
      <div>
        <input
          type="text"
          placeholder="Name"
          name="name"
          value={newExpense.name}
          onChange={handleInputChange}
        />
        <input
          type="number"
          placeholder="Amount"
          name="amount"
          value={newExpense.amount}
          onChange={handleInputChange}
        />
        <input
          type="text"
          placeholder="Category"
          name="category"
          value={newExpense.category}
          onChange={handleInputChange}
        />
        <input
          type="date"
          name="date"
          value={newExpense.date}
          onChange={handleInputChange}
        />
        <button onClick={handleAddExpense}>Add Expense</button>
      </div>

      {/* Expense Filter */}
      <div>
        {/* Add filtering options here */}
      </div>

      {/* Expense List */}
      <div>
        <h2>Expense List</h2>
        <ul>
          {expenses.map((expense, index) => (
            <li key={index}>
              {expense.name} - {expense.amount} - {expense.category} - {expense.date}
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
};

export default ExpenseTracker;

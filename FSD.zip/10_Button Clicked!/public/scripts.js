// Add an event listener to the button with the ID "myButton"
document.getElementById("myButton").addEventListener("click", function() {
    alert("Button Clicked!");
});

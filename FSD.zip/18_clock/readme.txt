npx create-react-app vegetable

src/
├── components/
│   ├── VegetableCategories/
│   │   ├── VegetableCategories.js
│   ├── App.js
├── index.js

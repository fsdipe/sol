import React, { useState, useEffect } from 'react';

function Clock() {
 const [time, setTime] = useState(new Date());

  useEffect(() => {
   const intervalID = setInterval(() => {
      setTime(new Date());
    }, 1000);

    // Clear the interval on component unmount to prevent memory leaks
    return () => {
      clearInterval(intervalID);
    };
  }, []);

 const formattedTime = time.toLocaleTimeString();

  return (
    <div className="clock">
      <h1>Digital Clock</h1>
      <p>{formattedTime}</p>
    </div>
  );
}

export default Clock;

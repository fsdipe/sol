const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const { check, validationResult } = require('express-validator');

const app = express();

// MongoDB connection
mongoose.connect('mongodb://localhost:27017/examdb1', {
    useNewUrlParser: true,
    useUnifiedTopology: true
});
const db = mongoose.connection;

db.once('open', () => {
    console.log('Connected to MongoDB');
});

// Create a schema for the Exam collection
const examSchema = new mongoose.Schema({
    name: String,
    email: String,
    city: String,
    dateOfExam: Date
});

const Exam = mongoose.model('Exam', examSchema);

// Middleware to parse form data
app.use(bodyParser.urlencoded({ extended: true }));

// Serve the HTML form
app.get('/', (req, res) => {
    res.sendFile(__dirname + '/form.html');
});

// Validate and insert data into MongoDB
app.post('/submit', async (req, res) => {
    const { name, email, city, date_of_exam } = req.body;
  
    try {
      const exam = new Exam({
        name,
        email,
        city,
        date_of_exam
      });
  
      await exam.save();
  
      res.send({ message: 'Exam data inserted successfully' });
    } catch (error) {
      res.status(400).send({ error: error.message });
    }
  });
const port = process.env.PORT || 3000;
app.listen(port, () => {
    console.log(`Server is running on port ${port}`);
});

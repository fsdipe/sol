install modules


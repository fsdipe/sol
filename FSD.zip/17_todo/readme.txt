npx create-react-app vegetable

src/
  |- TodoApp.js
  |- TodoItem.js
  |- TodoForm.js
  |- TodoList.js
  |- App.js
  |- index.js
  |- index.css



npm start

const express = require('express');
const bodyParser = require('body-parser');
const app = express();
const port = 3000;

// Use Pug as the view engine
app.set('view engine', 'pug');
app.set('views', __dirname + '/views');

// Parse application/x-www-form-urlencoded
app.use(bodyParser.urlencoded({ extended: false }));

// Serve static files (CSS, JS, etc.) if needed
// app.use(express.static(__dirname + '/public'));

// Define routes
app.get('/', (req, res) => {
  res.render('studentForm');
});

app.post('/data', (req, res) => {
 const { rollNo, name, division, email, subject } = req.body;
  res.render('displayData', { rollNo, name, division, email, subject });
});

// Start the server
app.listen(port, () => {
  console.log(`Server is running on http://localhost:${port}`);
});

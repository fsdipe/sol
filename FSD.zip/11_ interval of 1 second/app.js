const readline = require('readline');

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout,
});

let variable1 = 0;
let variable2 = 0;

function displaySum() {
 const result = variable1 + variable2;
  console.log(`Variable1 + Variable2 = ${result}`);
}

function incrementVariables() {
  variable1++;
  variable2++;
  displaySum();
}

// Ask the user for initial values
rl.question('Enter the initial value for Variable1: ', (initialValue1) => {
  rl.question('Enter the initial value for Variable2: ', (initialValue2) => {
    if (!isNaN(initialValue1) && !isNaN(initialValue2)) {
      variable1 = parseInt(initialValue1);
      variable2 = parseInt(initialValue2);
      displaySum();

      // Set up an interval to increment variables and display the sum
     const interval = setInterval(incrementVariables, 1000);

      // Allow the user to stop the script by pressing Enter
      rl.question('Press Enter to stop...', () => {
        clearInterval(interval);
        rl.close();
      });
    } else {
      console.log('Invalid initial values. Please enter numbers.');
      rl.close();
    }
  });
});

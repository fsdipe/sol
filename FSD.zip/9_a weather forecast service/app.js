const express = require('express');
const app = express();
const port = 3000;

// Set the view engine to Pug and specify the views directory
app.set('view engine', 'pug');
app.set('views', __dirname + '/views');

// Sample weather data
const weatherData = {
  NewYork: {
    location: 'New York',
    temperature: '75°F',
    description: 'Sunny',
  },
  LosAngeles: {
    location: 'Los Angeles',
    temperature: '80°F',
    description: 'Partly cloudy',
  },
};

// Serve a basic welcome message on the root URL ("/")
app.get('/', (req, res) => {
  res.send('<h1>Welcome to the Weather Forecast Service!</h1>');
});

// Route to handle weather queries ("/weather?location=...")
app.get('/weather', (req, res) => {
 const location = req.query.location;

  if (!location) {
    res.status(400).json({ error: 'Location parameter is missing.' });
    return;
  }

 const weatherInfo = weatherData[location];

  if (!weatherInfo) {
    res.status(404).json({ error: 'Location not found.' });
    return;
  }

  // Render the weather.pug template with the weather data
  res.render('weather', { weather: weatherInfo });
});

// Error handling for undefined routes
app.use((req, res) => {
  res.status(404).json({ error: 'Route not found.' });
});

app.listen(port, () => {
  console.log(`Server is running on http://localhost:${port}`);
});

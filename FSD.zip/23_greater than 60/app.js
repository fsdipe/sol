const mg = require("mongoose");
mg.connect("mongodb://127.0.0.1:27017/new").then(() => {
  console.log("Success");
}).catch((err) => {
  console.error(err);
});

const mySchema = new mg.Schema({
  name: {
    type: String,
    required: true,
  },
  surname: String,
  age: Number,
});

const perso = new mg.model("person", mySchema);

const createDoc = async () => {
  try {
    const personData1 = [
      { name: "jp", surname: "patel", age: 61 },
      { name: "holz", surname: "bbbdf", age: 38 },
      { name: "KK", surname: "pqr", age: 29 },
      { name: "ZZ", surname: "xyz", age: 62 }
    ];

    const result = [];

    result.push(await perso.insertMany(personData1));
    result.push(await perso.updateMany({ age: { $gt: 60 } }, { $set: { category: "SeniorCitizen" } }));
    result.push(await perso.find({ age: { $gte: 30, $lte: 60 } }).count());

    const surnamesAscending = await perso.find({}, { surname: 1, _id: 0 }).sort({ age: 1 }).exec();

    result.push(surnamesAscending);
    //to clean db
    result.push(await perso.deleteMany({}));
    result.push(await perso.find());

    console.log(result.length);
    console.log(result);
  } catch (err) {
    console.log(err);
  }
};

createDoc();

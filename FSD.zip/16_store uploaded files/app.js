const express = require('express');
const bodyParser = require('body-parser');

const app = express();
const port = process.env.PORT || 3000;

app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static('views'));

app.post('/submit', (req, res) => {
   const { username, password, confirmPassword, gender } = req.body;

    if (password === confirmPassword) {
        res.send(`
            <h1>Form Submitted Successfully</h1>
            <p>Username: ${username}</p>
            <p>Password: ${password}</p>
            <p>Gender: ${gender}</p>
        `);
    } else {
        res.send('<div class="error">Password and Confirm Password do not match.</div>');
    }
});

app.listen(port, () => {
    console.log(`Server is running on port ${port}`);
});

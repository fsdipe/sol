const express = require('express');
const multer = require('multer');
const path = require('path');

const app = express();
const port = 3000;

// Set up multer for file uploads
const storage = multer.memoryStorage();
const upload = multer({
  storage: storage,
  limits: {
    fileSize: 1024 * 1024, // 1MB file size limit
  },
  fileFilter: (req, file, cb) => {
   const allowedFileTypes = ['text/plain']; // Only allow plain text files
    if (allowedFileTypes.includes(file.mimetype)) {
      cb(null, true);
    } else {
      cb(new Error('Invalid file type. Only plain text files are allowed.'));
    }
  },
});

// Serve HTML form for file upload
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'index.html'));
});

// Handle file upload
app.post('/upload', upload.single('textFile'), (req, res) => {
  if (!req.file) {
    return res.status(400).send('No file uploaded.');
  }

 const fileContent = req.file.buffer.toString('utf-8');
  res.send(`File uploaded successfully. Content:\n${fileContent}`);
});

app.listen(port, () => {
  console.log(`Server is running on port ${port}`);
});

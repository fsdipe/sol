import React from 'react';
import './App.css';
import VegetableCategories from './components/VegetableCategories';

function App() {
  return (
    <div className="App">
      <VegetableCategories />
    </div>
  );
}

export default App;

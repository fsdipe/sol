import React, { useState } from 'react';


const VegetableCategories = () => {
 const vegetableData = {
    fruits: ['Tomato', 'Cucumber', 'Bell Pepper'],
    leafyGreens: ['Spinach', 'Kale', 'Lettuce'],
    rootVegetables: ['Carrot', 'Potato', 'Beetroot'],
    legumes: ['Lentils', 'Chickpeas', 'Black Beans'], // New category
  };

 const [selectedCategory, setSelectedCategory] = useState('fruits');

 const handleChangeCategory = (e) => {
    setSelectedCategory(e.target.value);
  };

  return (
    <div className="vegetable-categories">
      <h2>Vegetable Categories</h2>
      <div>
        <select value={selectedCategory} onChange={handleChangeCategory}>
          <option value="fruits">Fruits</option>
          <option value="leafyGreens">Leafy Greens</option>
          <option value="rootVegetables">Root Vegetables</option>
          <option value="legumes">Legumes</option>
        </select>
      </div>
      <div className="vegetables-list">
        {selectedCategory === 'Select Category' ? (
          <p>Please select a category.</p>
        ) : vegetableData[selectedCategory] ? (
          <ul>
            {vegetableData[selectedCategory].map((vegetable, index) => (
              <li key={index}>{vegetable}</li>
            ))}
          </ul>
        ) : (
          <p>Category not found.</p>
        )}
      </div>
    </div>
  );
};

export default VegetableCategories;

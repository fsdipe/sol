var ps=require("fs");
ps.writeFileSync("s1.txt","0 1000");
data=ps.readFileSync("S1.txt","utf-8");
data=data.split(" ");
data.sort();
var start = parseInt(data[0]);
var end = parseInt(data[1]);
console.log(start,end)

for (let i = start; i <= end; i++) {
    square = i * i;
    squarestr = square.toString();

    for (let j = 1; j < squarestr.length; j++) {
       const part1 = parseInt(squarestr.slice(0, j));
       const part2 = parseInt(squarestr.slice(j));

        if (part1 + part2 === i && part1 !== 0 && part2 !== 0) {
            console.log(i);
            break; 
        }
    }
}



    




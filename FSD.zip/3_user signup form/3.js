const express = require('express');
const cookieParser = require('cookie-parser');
const bodyParser = require('body-parser');
const app = express();
const port = 3000;

// Middleware to parse cookies
app.use(cookieParser());
app.use(bodyParser.urlencoded({ extended: false }));
// Serve the signup form
app.get('/', (req, res) => {
  res.send(`
    <html>
      <head>
        <title>User Signup</title>
      </head>
      <body>
        <h1>User Signup</h1>
        <form method="POST" action="/signup">
          <label>Name:</label>
          <input type="text" name="name"><br>

          <label>Contact Number:</label>
          <input type="text" name="contact"><br>

          <label>Email:</label>
          <input type="text" name="email"><br>

          <label>Address:</label>
          <textarea name="address"></textarea><br>

          <label>Gender:</label>
          <input type="radio" name="gender" value="Male"> Male
          <input type="radio" name="gender" value="Female"> Female
          <input type="radio" name="gender" value="Others"> Others<br>

          <label>Date of Birth:</label>
          <input type="date" name="dob"><br>

          <input type="submit" value="Submit">
        </form>
      </body>
    </html>
  `);
});

// Handle form submission and store user information in a cookie
app.post('/signup', (req, res) => {
 const { name, contact, email, address, gender, dob } = req.body;

  // Store user information in a cookie that expires in 15 seconds
  res.cookie('registered', JSON.stringify({ name, contact, email, address, gender, dob }), {
    maxAge: 15000,
  });

  res.send('Registration successful. <a href="/details">View Details</a>');
});

// Display the user's details stored in the cookie
app.get('/details', (req, res) => {
 const userCookie = req.cookies.registered;

  if (userCookie) {
   const userDetails = JSON.parse(userCookie);
    res.send(`
      <h1>User Details</h1>
      <p>Name: ${userDetails.name}</p>
      <p>Contact Number: ${userDetails.contact}</p>
      <p>Email: ${userDetails.email}</p>
      <p>Address: ${userDetails.address}</p>
      <p>Gender: ${userDetails.gender}</p>
      <p>Date of Birth: ${userDetails.dob}</p>
      <a href="/logout">Logout</a>
    `);
  } else {
    res.send('User details not found. <a href="/">Go back to Signup</a>');
  }
});

// Handle logout and remove the cookie
app.get('/logout', (req, res) => {
  res.clearCookie('registered');
  res.redirect('/');
});

app.listen(port, () => {
  console.log(`Server is running on port ${port}`);
});

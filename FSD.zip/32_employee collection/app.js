const mongoose = require('mongoose');
mongoose.connect("mongodb://127.0.0.1:27017/wmpm").then(() => {
  console.log("Success");
}).catch((err) => {
  console.error(err);
});


// Create a schema for the employee collection
const employeeSchema = new mongoose.Schema({
  _id: Number,
  name: String,
  age: Number,
  position: String,
  salary: Number,
  experience: Number // Adding the "experience" field
});

// Create a model for the employee collection
const Employee = mongoose.model('Employee', employeeSchema);

// Now, you can perform the tasks you mentioned
const createDoc = async () => {
    try {
      const personData1 = [{_id: 1,name: "Eric",age: 30,position: "Full Stack Developer",salary: 60000},
      {name: "Erica",age: 35,position: "Intern",salary: 8000},
      {name: "Erical",age: 40,position: "UX/UI Designer",salary: 56000},
      {name: "treric7",age: 37,position: "Team Leader",salary: 85000},
      {name: "Eliza",age: 25,position: "Software Developer",salary: 45000},
      {name: "Trian",age: 29,position: "Data Scientist",salary: 75000},
      {name: "Elizan",age: 25,position: "Full Stack Developer",salary: 
      42000}];
      
  
      const result = [];
  
      result.push(await Employee.insertMany(personData1));
      result.push(await Employee.updateOne({ age: 43, position: "Senior Manager" },{ $set: { experience: 17 } },{ upsert: true }));
      result.push(await Employee.find({}, {}, { sort: { salary: -1 } }));
      result.push(await Employee.find({ name: /ric/ }).count());
      result.push(await Employee.updateMany({ salary: { $lt: 45000 } },{ $mul: { salary: 1.1 } }));   
      result.push(await Employee.find({ name: /^[a-zA-Z]{4,5}$/ }));
      console.log(result);
    } catch (err) {
      console.log(err);
    }
  };
  
  createDoc();
  
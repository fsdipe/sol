import React, { useState } from 'react';

const WeatherApp = () => {
  const [city, setCity] = useState('');
  const [weatherData, setWeatherData] = useState(null);
  const [error, setError] = useState(null);

  // Function to handle input field changes
  const handleInputChange = (e) => {
    setCity(e.target.value);
  };

  // Function to fetch weather data
  const fetchWeatherData = () => {
    // In a real application, you would make an API request here.
    // For this example, we'll use a predefined set of data.
    const predefinedData = {
      cityName: 'ahmedabad',
      temperature: '110°F',
      description: 'Partly Cloudy',
    };

    setWeatherData(predefinedData);
    setError(null);
  };

  return (
    <div>
      <h1>Weather App</h1>
      <div>
        <input
          type="text"
          placeholder="Enter city name"
          value={city}
          onChange={handleInputChange}
        />
        <button onClick={fetchWeatherData}>Get Weather</button>
      </div>

      {error && <p className="error">{error}</p>}

      {weatherData && (
        <div>
          <h2>Weather in {weatherData.cityName}</h2>
          <p>Temperature: {weatherData.temperature}</p>
          <p>Description: {weatherData.description}</p>
        </div>
      )}
    </div>
  );
};

export default WeatherApp;

const EventEmitter = require('events');

// Create an instance of EventEmitter
const emitter = new EventEmitter();

// Listener 1
function listener1() {
  console.log('Listener 1 called');
}

// Listener 2
function listener2() {
  console.log('Listener 2 called');
}

// Add the listeners for the common event
emitter.on('commonEvent', listener1);
emitter.on('commonEvent', listener2);

// Emit the common event and call both listeners
emitter.emit('commonEvent');

// Get the number of listeners for the 'commonEvent'
const listenerCount = EventEmitter.listenerCount(emitter, 'commonEvent');
console.log(`Number of listeners for 'commonEvent': ${listenerCount}`);

// Remove one of the listeners (listener1)
emitter.removeListener('commonEvent', listener1);

// Emit the common event again and call the remaining listener (listener2)
emitter.emit('commonEvent');

// Get the number of remaining listeners for the 'commonEvent'
const remainingListenerCount = EventEmitter.listenerCount(emitter, 'commonEvent');
console.log(`Number of remaining listeners for 'commonEvent': ${remainingListenerCount}`);

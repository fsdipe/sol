const express = require('express');
const app = express();
const port = 3000;

// Set the view engine to Pug
app.set('view engine', 'pug');
app.set('views', './views');

// Serve static files (CSS)
app.use(express.static('public'));

// Sample product data
const products = [
  {
    id: 1,
    name: 'Product 1',
    description: 'Description for Product 1',
    price: 19.99,
  },
  {
    id: 2,
    name: 'Product 2',
    description: 'Description for Product 2',
    price: 29.99,
  },
  {
    id: 3,
    name: 'Product 3',
    description: 'Description for Product 3',
    price: 39.99,
  },
];

// Route to display a welcome message on the homepage
app.get('/', (req, res) => {
  res.send('<h1>Welcome to the Online Store!</h1>');
});

// Route to display a list of products
app.get('/products', (req, res) => {
  res.render('products', { products });
});

// Dynamic route for product details
app.get('/products/:id', (req, res) => {
 const productId = parseInt(req.params.id);
 const product = products.find((p) => p.id === productId);

  if (!product) {
    // Handle product not found
    res.render('error', { message: 'Product not found' });
  } else {
    res.render('product-details', { product });
  }
});

// 404 Error handler
app.use((req, res, next) => {
  res.status(404).render('error', { message: 'Page not found' });
});

app.listen(port, () => {
  console.log(`Server is running on http://localhost:${port}`);
});

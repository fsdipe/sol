import React, { useState } from 'react';


function StockDetail() {
 const [stocks, setStocks] = useState([]);
 const [name, setName] = useState('');
 const [purchasePrice, setPurchasePrice] = useState('');
 const [purchaseQuantity, setPurchaseQuantity] = useState('');
 const [sellingPrice, setSellingPrice] = useState('');
 const [sellingQuantity, setSellingQuantity] = useState('');

 const handleAddStock = () => {
   const purchaseQuantityInt = parseInt(purchaseQuantity);
   const sellingQuantityInt = parseInt(sellingQuantity);
   const purchasePriceFloat = parseFloat(purchasePrice);
   const sellingPriceFloat = parseFloat(sellingPrice);
  
    if (sellingQuantityInt > purchaseQuantityInt) {
      alert("Selling quantity cannot be more than purchase quantity.");
    } else {
     const profitLoss = sellingQuantityInt < purchaseQuantityInt ? "Invested" : ((sellingPriceFloat - purchasePriceFloat) * sellingQuantityInt).toFixed(2);
      setStocks([...stocks, { name, purchasePrice, purchaseQuantity, sellingPrice, sellingQuantity, profitLoss }]);
      setName('');
      setPurchasePrice('');
      setPurchaseQuantity('');
      setSellingPrice('');
      setSellingQuantity('');
    }
  };

  return (
    <div>
      <h2>Stock Detail</h2>
      <div>
        <input type="text" placeholder="Name" value={name} onChange={(e) => setName(e.target.value)} />
        <input type="number" placeholder="Purchase Price" value={purchasePrice} onChange={(e) => setPurchasePrice(e.target.value)} />
        <input type="number" placeholder="Purchase Quantity" value={purchaseQuantity} onChange={(e) => setPurchaseQuantity(e.target.value)} />
        <input type="number" placeholder="Selling Price" value={sellingPrice} onChange={(e) => setSellingPrice(e.target.value)} />
        <input type="number" placeholder="Selling Quantity" value={sellingQuantity} onChange={(e) => setSellingQuantity(e.target.value)} />
        <button onClick={handleAddStock}>Add Stock</button>
      </div>
      <table>
        <thead>
          <tr>
            <th>Name</th>
            <th>Purchase Price</th>
            <th>Purchase Quantity</th>
            <th>Selling Price</th>
            <th>Selling Quantity</th>
            <th>Profit/Loss</th>
          </tr>
        </thead>
        <tbody>
          {stocks.map((stock, index) => (
            <tr key={index}>
              <td>{stock.name}</td>
              <td>{stock.purchasePrice}</td>
              <td>{stock.purchaseQuantity}</td>
              <td>{stock.sellingPrice}</td>
              <td>{stock.sellingQuantity}</td>
              <td className={stock.profitLoss < 0 ? 'loss' : 'profit'}>{stock.profitLoss}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export default StockDetail;

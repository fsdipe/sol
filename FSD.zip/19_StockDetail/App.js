import React from 'react';
import './App.css';
import StockDetail from './components/StockDetail';

function App() {
  return (
    <div className="App">
      <StockDetail />
    </div>
  );
}

export default App;

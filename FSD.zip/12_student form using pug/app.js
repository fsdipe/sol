const express = require('express');
const bodyParser = require('body-parser');
const app = express();

// Set up Pug as the view engine
app.set('view engine', 'pug');

// Middleware for parsing form data
app.use(bodyParser.urlencoded({ extended: false }));

// Serve static files (e.g., CSS or images) if needed
app.use(express.static('public'));

// Render the student form
app.get('/', (req, res) => {
  res.render('student-form');
});

// Handle form submission
app.post('/student', (req, res) => {
 const { name, email, course } = req.body;
  
  // Render the 'student' page with the submitted data
  res.render('student', { name, email, course });
});

// Start the server
const port = process.env.PORT || 3000;
app.listen(port, () => {
  console.log(`Server is running on port ${port}`);
});

const express = require('express');
const session = require('express-session');
const bodyParser = require('body-parser'); // Import body-parser

const app = express();
const port = 3000;

// Configure sessions
app.use(session({
  secret: 'your_secret_key', // Replace with your own secret key
  resave: false,
  saveUninitialized: true,
}));

// Use body-parser middleware to parse form data
app.use(bodyParser.urlencoded({ extended: true }));

// Serve static files (HTML)
app.use(express.static(__dirname));

// Middleware to save session and redirect to fetchsession page
app.post('/savesession', (req, res) => {
 const { username } = req.body; // Now, req.body should contain the username
  req.session.username = username;
  res.redirect('/fetchsession');
});

// Middleware to fetch session value
app.get('/fetchsession', (req, res) => {
 const username = req.session.username;
  res.send(`<h1>Welcome, ${username}!</h1><a href="/deletesession">Logout</a>`);
});

// Middleware to delete session and redirect to index.html
app.get('/deletesession', (req, res) => {
  req.session.destroy(err => {
    if (err) {
      console.error(err);
    }
    res.redirect('/');
  });
});

app.listen(port, () => {
  console.log(`Server is running on port ${port}`);
});

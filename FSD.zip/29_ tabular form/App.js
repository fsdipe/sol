import React from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';

import SubjectTable from './components/SubjectTable';
import ContentPage from './components/ContentPage';

function App() {
  return (
    <Router>
      <div className="App">
        <Routes>
          <Route path="/" element={<SubjectTable />} />
          <Route path="/FSD2/:content" element={<ContentPage />} />
          <Route path="/NoPage" element={<div><h2>No page found!</h2></div>} />
        </Routes>
      </div>
    </Router>
  );
}

export default App;

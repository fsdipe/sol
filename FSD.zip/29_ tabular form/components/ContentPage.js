import React from 'react';
import { useParams, Navigate } from 'react-router-dom';

const contentData = {
  JSON: 'This is JSON content.',
  NodeJS: 'This is NodeJS/ExpressJS content.',
  ReactJS: 'This is React JS content.',
};

const ContentPage = () => {
  const { content } = useParams();

  // Check if the content is valid
  const isValidContent = content in contentData;

  if (!isValidContent) {
    return <Navigate to="/NoPage" />;
  }

  return (
    <div>
      <h2>Subject: FSD2</h2>
      <h3>Content: {content}</h3>
      <p>{contentData[content]}</p>
    </div>
  );
};

export default ContentPage;

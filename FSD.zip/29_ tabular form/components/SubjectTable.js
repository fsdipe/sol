import React from 'react';
import { Link } from 'react-router-dom';

const subjects = [
  { id: 'JSON', name: 'JSON' },
  { id: 'NodeJS', name: 'NodeJS/ExpressJS' },
  { id: 'ReactJS', name: 'React JS' },
];

const SubjectTable = () => {
  return (
    <div>
      <h2>Subject Index</h2>
      <table>
        <thead>
          <tr>
            <th>Subject</th>
          </tr>
        </thead>
        <tbody>
          {subjects.map((subject) => (
            <tr key={subject.id}>
              <td>
                <Link to={`/FSD2/${subject.id}`}>{subject.name}</Link>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default SubjectTable;

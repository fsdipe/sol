const fs = require('fs');

const sourceFilePath = 's1.txt';
const destinationFilePath = 'destination.txt';

// Read content from the source file asynchronously
fs.readFile(sourceFilePath, 'utf8', (err, data) => {
  if (err) {
    console.error(`Error reading ${sourceFilePath}: ${err}`);
    return;
  }

  // Write the content to the destination file asynchronously
  fs.writeFile(destinationFilePath, data, 'utf8', (err) => {
    if (err) {
      console.error(`Error writing to ${destinationFilePath}: ${err}`);
    } else {
      console.log(`Content from ${sourceFilePath} has been copied to ${destinationFilePath}`);
    }
  });
});

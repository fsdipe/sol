const express = require('express');
const session = require('express-session');
const app = express();
const port = 3000;

// Configure session middleware
app.use(session({
  secret: 'my-secret-key',
  resave: false,
  saveUninitialized: true
}));

app.use(express.urlencoded({ extended: true }));
app.use(express.static('public'));

// Display the index.html page
app.get('/', (req, res) => {
  res.sendFile(__dirname + '/public/index.html');
});

// Save the username in session and redirect to "fetchsession" page
app.post('/savesession', (req, res) => {
  const username = req.body.username;
  req.session.username = username;
  res.redirect('/fetchsession');
});

// Display the session value and a logout link
app.get('/fetchsession', (req, res) => {
  const username = req.session.username;

  if (username) {
    res.send(`
      <h1>Session Data</h1>
      <p>Username: ${username}</p>
      <a href="/deletesession">Logout</a>
    `);
  } else {
    res.send('Session data not found. <a href="/">Go back</a>');
  }
});

// Delete the session and redirect to the index.html page
app.get('/deletesession', (req, res) => {
  req.session.destroy();
  res.redirect('/');
});

app.listen(port, () => {
  console.log(`Server is running on http://localhost:${port}`);
});

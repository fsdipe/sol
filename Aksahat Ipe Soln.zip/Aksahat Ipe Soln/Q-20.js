import React, { useState } from 'react';

const vegetableData = {
  fruits: ['Tomato', 'Cucumber', 'Bell Pepper', 'Apple', 'Banana', 'Grapes'],
  leafyGreens: ['Spinach', 'Kale', 'Lettuce'],
  rootVegetables: ['Carrot', 'Potato', 'Beetroot'],
  legumes: ['Lentils', 'Chickpeas', 'Black Beans'],
};

function VegetableCategories() {
  const [selectedCategory, setSelectedCategory] = useState('fruits');
  const [errorMessage, setErrorMessage] = useState('');

  const handleCategoryChange = (e) => {
    const category = e.target.value;
    setSelectedCategory(category);
    setErrorMessage('');
  };

  return (
    <div className="vegetable-categories">
      <h2>Vegetable Categories</h2>
      <div className="category-dropdown">
        <label htmlFor="categorySelect">Select a Category:</label>
        <select
          id="categorySelect"
          value={selectedCategory}
          onChange={handleCategoryChange}
        >
          <option value="fruits">Fruits</option>
          <option value="leafyGreens">Leafy Greens</option>
          <option value="rootVegetables">Root Vegetables</option>
          <option value="legumes">Legumes</option>
        </select>
      </div>

      <div className="vegetable-list">
        {selectedCategory === 'Select Category' ? (
          <p>Please select a category.</p>
        ) : vegetableData[selectedCategory] ? (
          <ul>
            {vegetableData[selectedCategory].map((vegetable, index) => (
              <li key={index}>{vegetable}</li>
            ))}
          </ul>
        ) : (
          <p>Category not found.</p>
        )}
      </div>
    </div>
  );
}

export default VegetableCategories;

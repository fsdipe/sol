const fs = require('fs');

function copyFile(sourcePath, destinationPath, callback) {
  fs.readFile(sourcePath, 'utf8', (readErr, data) => {
    if (readErr) {
      return callback(readErr);
    }

    fs.writeFile(destinationPath, data, 'utf8', (writeErr) => {
      if (writeErr) {
        return callback(writeErr);
      }

      callback(null, 'File copied successfully.');
    });
  });
}

const sourceFile = 'source.txt';
const destinationFile = 'destination.txt';

copyFile(sourceFile, destinationFile, (err, message) => {
  if (err) {
    console.error('Error:', err);
  } else {
    console.log(message);
  }
});

const http = require('http');
const fs = require('fs');
const path = require('path');

const server = http.createServer((req, res) => {
  // Check if the request URL is for the root path ("/")
  if (req.url === '/') {
    // Read the HTML file
    fs.readFile(path.join(__dirname, 'simple.html'), 'utf8', (err, data) => {
      if (err) {
        // Handle file read error
        res.writeHead(500, { 'Content-Type': 'text/plain' });
        res.end('Internal Server Error');
      } else {
        // Set the HTTP response headers and send the HTML content
        res.writeHead(200, { 'Content-Type': 'text/html' });
        res.end(data);
      }
    });
  } else {
    // Handle other URLs (e.g., 404 Not Found)
    res.writeHead(404, { 'Content-Type': 'text/plain' });
    res.end('Not Found');
  }
});

const port = 3000;

server.listen(port, () => {
  console.log(`Server is running on http://localhost:${port}`);
});

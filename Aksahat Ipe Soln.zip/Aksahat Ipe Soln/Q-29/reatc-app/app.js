import React from 'react';
import { BrowserRouter as Router, Route, Switch, Link } from 'react-router-dom';
import './App.css';
import SubjectIndex from './SubjectIndex';
import Content from './Content';
import NoPage from './NoPage';

function App() {
  return (
    <Router>
      <div className="App">
        <nav>
          <ul>
            <li>
              <Link to="/FSD2">FSD2</Link>
            </li>
            {/* Add more links for other subjects here */}
          </ul>
        </nav>

        <Switch>
          <Route path="/FSD2" component={Content} />
          {/* Add more routes for other subjects here */}
          <Route path="/" component={NoPage} />
        </Switch>
      </div>
    </Router>
  );
}

export default App;

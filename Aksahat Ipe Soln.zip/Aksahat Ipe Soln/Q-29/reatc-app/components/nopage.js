import React from 'react';

const NoPage = () => {
  return (
    <div>
      <h2>No Page</h2>
      <p>Page not found.</p>
    </div>
  );
};

export default NoPage;

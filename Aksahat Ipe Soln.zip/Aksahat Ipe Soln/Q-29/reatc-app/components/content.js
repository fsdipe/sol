import React from 'react';

const Content = () => {
  return (
    <div>
      <h2>Subject: FSD2</h2>
      <table>
        <tr>
          <td>JSON</td>
          <td>NodeJS/ExpressJS</td>
          <td>React JS</td>
        </tr>
      </table>
    </div>
  );
};

export default Content;

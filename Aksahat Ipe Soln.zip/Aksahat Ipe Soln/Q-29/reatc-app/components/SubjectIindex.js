import React from 'react';
import { Link } from 'react-router-dom';

const SubjectIndex = () => {
  return (
    <div>
      <h2>Subject Index</h2>
      <table>
        <tr>
          <td>
            <Link to="/FSD2">FSD2</Link>
          </td>
        </tr>
        {/* Add more subject links here */}
      </table>
    </div>
  );
};

export default SubjectIndex;

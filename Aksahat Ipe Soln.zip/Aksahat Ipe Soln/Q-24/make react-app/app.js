import React, { useState } from 'react';
import './App.css';

function App() {
  const [text, setText] = useState('Hello');
  const [color, setColor] = useState('red');
  const [isHidden, setIsHidden] = useState(false);

  const toggleText = () => {
    setText(text === 'Hello' ? 'Welcome' : 'Hello');
  };

  const toggleColor = () => {
    setColor(color === 'red' ? 'blue' : 'red');
  };

  const toggleVisibility = () => {
    setIsHidden(!isHidden);
  };

  return (
    <div className="App">
      <h1 style={{ color }}>{text}</h1>
      <button onClick={toggleText}>Change Text</button>
      <button onDoubleClick={toggleColor}>Change Color</button>
      <button onClick={toggleVisibility}>{isHidden ? 'Show' : 'Hide'}</button>
      {!isHidden && <h2>Good Morning</h2>}
    </div>
  );
}

export default App;

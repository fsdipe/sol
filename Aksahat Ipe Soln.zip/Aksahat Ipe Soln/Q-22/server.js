const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');

const app = express();
const port = 3000;

// Connect to MongoDB (replace 'mongodb://localhost/your-db-name' with your database URI)
mongoose.connect('mongo/url', {
  useNewUrlParser: true,
  useUnifiedTopology: true,
});

// Create a schema for the "details" collection
const detailsSchema = new mongoose.Schema({
  name: { type: String, trim: true, required: true, minlength: 3, maxlength: 12, uppercase: true },
  email: { type: String, required: true, match: /^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}$/ },
  date: { type: Date, required: true, min: '2010-01-01', max: '2022-12-31' },
});

// Create a model based on the schema
const Details = mongoose.model('Details', detailsSchema);

app.use(bodyParser.urlencoded({ extended: true }));

// Serve the HTML form
app.get('/', (req, res) => {
  res.sendFile(__dirname + '/form.html');
});

// Handle form submission
app.post('/submit', (req, res) => {
  const { name, email, date } = req.body;

  // Create a new Details document and save it to the database
  const details = new Details({
    name,
    email,
    date,
  });

  details.save((err) => {
    if (err) {
      console.error(err);
      res.send('Error occurred while saving data.');
    } else {
      res.send('Data saved successfully.');
    }
  });
});

app.listen(port, () => {
  console.log(`Server is running on http://localhost:${port}`);
});

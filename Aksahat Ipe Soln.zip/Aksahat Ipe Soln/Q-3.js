const express = require('express');
const cookieParser = require('cookie-parser');

const app = express();
const port = 3000;

app.use(express.urlencoded({ extended: true }));
app.use(cookieParser());

// Serve HTML form for user registration
app.get('/', (req, res) => {
  res.send(`
    <h1>User Signup</h1>
    <form method="post" action="/register">
      <label for="name">Name:</label>
      <input type="text" id="name" name="name" required><br>

      <label for="contact">Contact Number:</label>
      <input type="tel" id="contact" name="contact" required><br>

      <label for="email">Email:</label>
      <input type="email" id="email" name="email" required><br>

      <label for="address">Address:</label>
      <textarea id="address" name="address" required></textarea><br>

      <label>Gender:</label>
      <input type="radio" id="male" name="gender" value="Male" required>
      <label for="male">Male</label>
      <input type="radio" id="female" name="gender" value="Female" required>
      <label for="female">Female</label>
      <input type="radio" id="others" name="gender" value="Others" required>
      <label for="others">Others</label><br>

      <label for="dob">Date of Birth:</label>
      <input type="date" id="dob" name="dob" required><br>

      <input type="submit" value="Submit">
    </form>
  `);
});

// Handle user registration
app.post('/register', (req, res) => {
  const userData = {
    name: req.body.name,
    contact: req.body.contact,
    email: req.body.email,
    address: req.body.address,
    gender: req.body.gender,
    dob: req.body.dob,
  };

  // Store user data in a cookie named "registered" that expires in 15 seconds
  res.cookie('registered', JSON.stringify(userData), { maxAge: 15000 });

  res.send('<h2>Registration successful! <a href="/details">View Details</a></h2>');
});

// Display user details from the "registered" cookie
app.get('/details', (req, res) => {
  const userData = req.cookies['registered'];

  if (userData) {
    res.send(`
      <h1>User Details</h1>
      <pre>${userData}</pre>
      <p><a href="/logout">Logout</a></p>
    `);
  } else {
    res.send('<h2>No user data found. <a href="/">Register</a></h2>');
  }
});

// Logout and clear the "registered" cookie
app.get('/logout', (req, res) => {
  res.clearCookie('registered');
  res.redirect('/');
});

app.listen(port, () => {
  console.log(`Server is running on http://localhost:${port}`);
});

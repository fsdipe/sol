let variable1 = 0;
let variable2 = 0;

const interval = setInterval(() => {
  variable1++;
  variable2++;

  const addition = variable1 + variable2;
  console.log(`Variable1: ${variable1}, Variable2: ${variable2}, Addition: ${addition}`);
}, 1000); // Execute the function every 1000 milliseconds (1 second)

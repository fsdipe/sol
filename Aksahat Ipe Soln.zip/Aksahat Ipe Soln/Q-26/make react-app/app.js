import React, { useState, useEffect } from 'react';
import axios from 'axios';

const ExpenseTracker = () => {
  const [expenses, setExpenses] = useState([]);
  const [newExpense, setNewExpense] = useState({
    name: '',
    amount: '',
    category: '',
    date: '',
  });
  const [categories, setCategories] = useState([]);
  const [filterCategory, setFilterCategory] = useState('');
  const [filterDate, setFilterDate] = useState('');
  const [error, setError] = useState(null);

  useEffect(() => {
    // Fetch expenses and categories from the server when the component mounts
    axios.get('/expenses')
      .then((response) => {
        setExpenses(response.data.expenses);
        setCategories(response.data.categories);
      })
      .catch((error) => {
        setError('Error fetching expenses');
      });
  }, []);

  const handleInputChange = (event) => {
    const { name, value } = event.target;
    setNewExpense({
      ...newExpense,
      [name]: value,
    });
  };

  const addExpense = () => {
    axios.post('/expenses', newExpense)
      .then((response) => {
        setExpenses([...expenses, response.data]);
        setNewExpense({
          name: '',
          amount: '',
          category: '',
          date: '',
        });
      })
      .catch((error) => {
        setError('Error adding expense');
      });
  };

  const filterExpenses = () => {
    axios.get(`/expenses?category=${filterCategory}&date=${filterDate}`)
      .then((response) => {
        setExpenses(response.data);
      })
      .catch((error) => {
        setError('Error filtering expenses');
      });
  };

  return (
    <div>
      <h1>Expense Tracker</h1>
      <div>
        <input
          type="text"
          name="name"
          placeholder="Name"
          value={newExpense.name}
          onChange={handleInputChange}
        />
        <input
          type="number"
          name="amount"
          placeholder="Amount"
          value={newExpense.amount}
          onChange={handleInputChange}
        />
        <input
          type="text"
          name="category"
          placeholder="Category"
          value={newExpense.category}
          onChange={handleInputChange}
        />
        <input
          type="date"
          name="date"
          placeholder="Date"
          value={newExpense.date}
          onChange={handleInputChange}
        />
        <button onClick={addExpense}>Add Expense</button>
      </div>
      <div>
        <select
          name="category"
          value={filterCategory}
          onChange={(e) => setFilterCategory(e.target.value)}
        >
          <option value="">All Categories</option>
          {categories.map((category) => (
            <option key={category} value={category}>
              {category}
            </option>
          ))}
        </select>
        <input
          type="date"
          name="date"
          placeholder="Filter by Date"
          value={filterDate}
          onChange={(e) => setFilterDate(e.target.value)}
        />
        <button onClick={filterExpenses}>Filter</button>
      </div>
      {error && <p>{error}</p>}
      <ul>
        {expenses.map((expense) => (
          <li key={expense.id}>
            <div>{expense.name}</div>
            <div>Amount: {expense.amount}</div>
            <div>Category: {expense.category}</div>
            <div>Date: {expense.date}</div>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default ExpenseTracker;

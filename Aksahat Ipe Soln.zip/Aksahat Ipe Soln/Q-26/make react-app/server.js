const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');

const app = express();
const port = process.env.PORT || 5000;

// Middleware
app.use(cors());
app.use(express.json());

// MongoDB connection
mongoose.connect('mongodb://localhost/Task', {
  useNewUrlParser: true,
  useUnifiedTopology: true,
});

// Expense Schema
const expenseSchema = new mongoose.Schema({
  name: String,
  amount: Number,
  category: String,
  date: Date,
});

const Expense = mongoose.model('Expense', expenseSchema);

// Routes
app.get('/expenses', async (req, res) => {
  try {
    // Fetch expenses based on query parameters (category and date)
    const { category, date } = req.query;
    const query = {};

    if (category) {
      query.category = category;
    }

    if (date) {
      query.date = date;
    }

    const expenses = await Expense.find(query);
    const categories = await Expense.distinct('category');

    res.json({ expenses, categories });
  } catch (error) {
    res.status(500).json({ error: 'Internal server error' });
  }
});

app.post('/expenses', async (req, res) => {
  try {
    const { name, amount, category, date } = req.body;
    const newExpense = new Expense({ name, amount, category, date });
    const savedExpense = await newExpense.save();
    res.status(201).json(savedExpense);
  } catch (error) {
    res.status(500).json({ error: 'Internal server error' });
  }
});


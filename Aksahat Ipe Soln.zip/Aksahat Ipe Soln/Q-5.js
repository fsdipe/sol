const express = require('express');
const fileUpload = require('express-fileupload');
const path = require('path');

const app = express();
const port = 3000;

// Use express-fileupload middleware
app.use(fileUpload());

// Serve an HTML form for file upload
app.get('/', (req, res) => {
  res.send(`
    <h1>Text File Upload</h1>
    <form method="post" action="/upload" enctype="multipart/form-data">
      <input type="file" name="textFile" accept=".txt">
      <input type="submit" value="Upload">
    </form>
  `);
});

// Handle file upload
app.post('/upload', (req, res) => {
  if (!req.files || Object.keys(req.files).length === 0) {
    return res.status(400).send('No files were uploaded.');
  }

  const textFile = req.files.textFile;

  // Check file format
  if (textFile.mimetype !== 'text/plain') {
    return res.status(400).send('Only text files (.txt) are allowed.');
  }

  // Check file size (1MB limit)
  if (textFile.data.length > 1 * 1024 * 1024) {
    return res.status(400).send('File size exceeds the 1MB limit.');
  }

  // Move the uploaded file to a specific directory (optional)
  const uploadPath = path.join(__dirname, 'uploads', textFile.name);
  textFile.mv(uploadPath, (err) => {
    if (err) {
      return res.status(500).send(err);
    }

    res.send('File uploaded successfully.');
  });
});

app.listen(port, () => {
  console.log(`Server is running on http://localhost:${port}`);
});

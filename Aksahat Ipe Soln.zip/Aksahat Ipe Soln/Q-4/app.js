const express = require('express');
const bodyParser = require('body-parser');
const path = require('path');

const app = express();
const port = 3000;

// Set Pug as the view engine
app.set('view engine', 'pug');
app.set('views', path.join(__dirname, 'views'));

// Use bodyParser middleware to parse form data
app.use(bodyParser.urlencoded({ extended: false }));

// Serve the student form page
app.get('/', (req, res) => {
  res.render('studentForm');
});

// Handle form submission and display data
app.post('/data', (req, res) => {
  const studentData = {
    rollNo: req.body.rollNo,
    name: req.body.name,
    division: req.body.division,
    email: req.body.email,
    subject: req.body.subject,
  };

  res.render('data', { studentData });
});

app.listen(port, () => {
  console.log(`Server is running on http://localhost:${port}`);
});

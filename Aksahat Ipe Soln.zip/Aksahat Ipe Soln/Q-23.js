const MongoClient = require('mongodb').MongoClient;

// Connection URL
const url = 'your url';

// Database Name
const dbName = 'akshat';

// Create a new MongoClient
const client = new MongoClient(url, { useNewUrlParser: true, useUnifiedTopology: true });

// Connect to MongoDB server
client.connect((err) => {
  if (err) {
    console.error('Error connecting to MongoDB:', err);
    return;
  }

  console.log('Connected to MongoDB server');

  // Get the reference to the maindata database
  const db = client.db(dbName);

  // Get the userdata collection
  const userdata = db.collection('userdata');

  // Task 1: Insert a category field with value "SeniorCitizen" having age greater than 60.
  userdata.updateMany({ age: { $gt: 60 } }, { $set: { category: 'SeniorCitizen' } }, (err, result) => {
    if (err) {
      console.error('Error inserting category:', err);
      return;
    }

    console.log(`${result.modifiedCount} documents updated with category "SeniorCitizen"`);

    // Task 2: Sort the collection by age in descending order and display the youngest person's name only.
    userdata.find().sort({ age: -1 }).limit(1).project({ _id: 0, name: 1 }).toArray((err, youngest) => {
      if (err) {
        console.error('Error sorting and displaying youngest person:', err);
        return;
      }

      console.log('Youngest person:', youngest[0].name);

      // Task 3: Display total number of documents having age between 30 and 60 only.
      userdata.countDocuments({ age: { $gte: 30, $lte: 60 } }, (err, count) => {
        if (err) {
          console.error('Error counting documents between 30 and 60:', err);
          return;
        }

        console.log('Total number of documents between 30 and 60:', count);

        // Task 4: Display only surname field in ascending order of age.
        userdata.find({}, { _id: 0, surname: 1 }).sort({ age: 1 }).toArray((err, surnames) => {
          if (err) {
            console.error('Error sorting and displaying surnames:', err);
            return;
          }

          console.log('Surnames in ascending order of age:', surnames);

          // Task 5: Delete the record having age greater than 60.
          userdata.deleteMany({ age: { $gt: 60 } }, (err, deleted) => {
            if (err) {
              console.error('Error deleting records with age greater than 60:', err);
              return;
            }

            console.log(`${deleted.deletedCount} documents deleted`);

            // Close the MongoDB connection
            client.close();
          });
        });
      });
    });
  });
});

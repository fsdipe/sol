// Add an event listener to the button element with the ID "myButton"
const myButton = document.getElementById("myButton");

myButton.addEventListener("click", function() {
  alert("Button Clicked!");
});

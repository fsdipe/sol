const Employee = require('./employeeModel');

// Task 1: Update or Insert an Employee
Employee.findOneAndUpdate(
  { age: 43, position: 'Senior Manager' },
  { $set: { experience: 17 } },
  { upsert: true, new: true },
  (err, employee) => {
    if (err) console.error(err);
    else console.log('Task 1 Result:', employee);
  }
);

// Task 2: Find Employee with Highest Salary
Employee.findOne({})
  .sort('-salary')
  .exec((err, employee) => {
    if (err) console.error(err);
    else console.log('Task 2 Result:', employee.name, employee.position);
  });

// Task 3: Count Employees with Name Like "%ric%"
Employee.countDocuments({ name: /ric/ }, (err, count) => {
  if (err) console.error(err);
  else console.log('Task 3 Result:', count);
});

// Task 4: Increase Salary by 10% for Employees with Salary < 45000
Employee.updateMany(
  { salary: { $lt: 45000 } },
  { $mul: { salary: 1.1 } },
  (err, result) => {
    if (err) console.error(err);
    else console.log('Task 4 Result:', result);
  }
);

// Task 5: Find Employees with Names Containing Only 4 or 5 Letters
Employee.find({
  name: { $regex: /^[A-Za-z]{4,5}$/ },
})
  .select('position')
  .exec((err, employees) => {
    if (err) console.error(err);
    else console.log('Task 5 Result:', employees.map((emp) => emp.position));
  });

  
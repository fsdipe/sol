const fs = require('fs');

function isKaprekarNumber(n) {
  if (n === 1) return false; // 1 is not considered a Kaprekar number

  const square = n * n;
  const squareStr = square.toString();

  for (let i = 1; i < squareStr.length; i++) {
    const leftPart = parseInt(squareStr.slice(0, i));
    const rightPart = parseInt(squareStr.slice(i));

    if (leftPart + rightPart === n && leftPart !== 0 && rightPart !== 0) {
      return true;
    }
  }

  return false;
}

function findKaprekarNumbersInRange(start, end) {
  const kaprekarNumbers = [];

  for (let num = start; num <= end; num++) {
    if (isKaprekarNumber(num)) {
      kaprekarNumbers.push(num);
    }
  }

  return kaprekarNumbers;
}

const start = 1;
const end = 1000;

const kaprekarNumbers = findKaprekarNumbersInRange(start, end);

const outputPath = 'kaprekar_numbers.txt';

fs.writeFile(outputPath, kaprekarNumbers.join('\n'), (err) => {
  if (err) {
    console.error('Error writing to file:', err);
  } else {
    console.log('Kaprekar numbers written to', outputPath);
  }
});

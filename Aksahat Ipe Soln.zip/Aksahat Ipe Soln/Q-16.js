const express = require('express');
const app = express();
const port = 3000;

// Middleware to parse form data
app.use(express.urlencoded({ extended: true }));

app.get('/', (req, res) => {
  // Display the HTML form
  res.send(`
    <html>
    <head>
      <title>Form Example</title>
      <style>
        .error {
          color: red;
        }
      </style>
    </head>
    <body>
      <h1>Form Example</h1>
      <form method="post" action="/process-form">
        <label for="username">Username:</label>
        <input type="text" id="username" name="username" required><br>

        <label for="password">Password:</label>
        <input type="password" id="password" name="password" required><br>

        <label for="confirmPassword">Confirm Password:</label>
        <input type="password" id="confirmPassword" name="confirmPassword" required><br>

        <label for="gender">Gender:</label>
        <select id="gender" name="gender" required>
          <option value="male">Male</option>
          <option value="female">Female</option>
          <option value="other">Other</option>
        </select><br>

        <input type="submit" value="Submit">
        <input type="reset" value="Reset">
      </form>
    </body>
    </html>
  `);
});

app.post('/process-form', (req, res) => {
  const { username, password, confirmPassword, gender } = req.body;

  if (password === confirmPassword) {
    // Passwords match, process the form
    res.send(`
      <h2>Form Submitted Successfully</h2>
      <p>Username: ${username}</p>
      <p>Password: ${password}</p>
      <p>Gender: ${gender}</p>
    `);
  } else {
    // Passwords don't match, display a warning message in red
    res.send('<p class="error">Password and Confirm Password do not match.</p>');
  }
});

app.listen(port, () => {
  console.log(`Server is running on http://localhost:${port}`);
});

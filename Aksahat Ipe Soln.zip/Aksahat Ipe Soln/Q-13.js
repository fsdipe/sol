const EventEmitter = require('events');

class ShapeCalculator extends EventEmitter {
  calculateCircleArea(radius) {
    if (radius < 0) {
      this.emit('negativeRadius', 'Radius must be positive');
    } else {
      const area = Math.PI * Math.pow(radius, 2);
      this.emit('circleArea', area);
    }
  }

  calculateSquarePerimeter(side) {
    if (side < 0) {
      this.emit('negativeSide', 'Side must be positive');
    } else {
      const perimeter = 4 * side;
      this.emit('squarePerimeter', perimeter);
    }
  }
}

const calculator = new ShapeCalculator();

calculator.on('circleArea', (area) => {
  console.log(`Area of the circle: ${area.toFixed(2)}`);
});

calculator.on('negativeRadius', (message) => {
  console.error(message);
});

calculator.on('squarePerimeter', (perimeter) => {
  console.log(`Perimeter of the square: ${perimeter}`);
});

calculator.on('negativeSide', (message) => {
  console.error(message);
});

// Example usage:
calculator.calculateCircleArea(5); // Calculate circle area with radius 5
calculator.calculateCircleArea(-3); // Display error message for negative radius

calculator.calculateSquarePerimeter(4); // Calculate square perimeter with side 4
calculator.calculateSquarePerimeter(-2); // Display error message for negative side

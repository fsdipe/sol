import React, { useState } from 'react';
import axios from 'axios';

const StudentForm = () => {
  const [formData, setFormData] = useState({
    subject: 'FSD2', // Default subject
    marks: '',
  });

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      // Send a POST request to your server to insert the data into the MongoDB database
      const response = await axios.post('/api/insertStudentData', formData);
      console.log('Data inserted:', response.data);
    } catch (error) {
      console.error('Error inserting data:', error);
    }
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };

  return (
    <div>
      <h2>Student Data Form</h2>
      <form onSubmit={handleSubmit}>
        <div>
          <label htmlFor="subject">Subject Name:</label>
          <select
            id="subject"
            name="subject"
            value={formData.subject}
            onChange={handleInputChange}
          >
            <option value="FSD2">FSD2</option>
            <option value="FCSP2">FCSP2</option>
            <option value="DS">DS</option>
            <option value="TOC">TOC</option>
            <option value="COA">COA</option>
          </select>
        </div>
        <div>
          <label htmlFor="marks">Marks:</label>
          <input
            type="text"
            id="marks"
            name="marks"
            value={formData.marks}
            onChange={handleInputChange}
          />
        </div>
        <button type="submit">Submit</button>
      </form>
    </div>
  );
};

export default StudentForm;

import React, { useState, useEffect } from 'react';
import axios from 'axios';

const App = () => {
  const [tasks, setTasks] = useState([]);
  const [newTask, setNewTask] = useState('');
  const [filter, setFilter] = useState('all');

  useEffect(() => {
    // Fetch tasks from the MongoDB collection when the component mounts
    axios.get('/tasks')
      .then((response) => {
        setTasks(response.data);
      })
      .catch((error) => {
        console.error('Error fetching tasks:', error);
      });
  }, []);

  const addTask = () => {
    if (newTask.trim() !== '') {
      axios.post('/tasks', { task: newTask })
        .then((response) => {
          setTasks([...tasks, response.data]);
          setNewTask('');
        })
        .catch((error) => {
          console.error('Error adding task:', error);
        });
    }
  };

  const toggleTaskCompletion = (taskId) => {
    axios.put(`/tasks/${taskId}`)
      .then((response) => {
        const updatedTasks = tasks.map((task) =>
          task._id === taskId ? { ...task, completed: !task.completed } : task
        );
        setTasks(updatedTasks);
      })
      .catch((error) => {
        console.error('Error toggling task completion:', error);
      });
  };

  const deleteTask = (taskId) => {
    axios.delete(`/tasks/${taskId}`)
      .then(() => {
        const updatedTasks = tasks.filter((task) => task._id !== taskId);
        setTasks(updatedTasks);
      })
      .catch((error) => {
        console.error('Error deleting task:', error);
      });
  };

  const filteredTasks = tasks.filter((task) => {
    if (filter === 'all') return true;
    if (filter === 'completed') return task.completed;
    if (filter === 'incomplete') return !task.completed;
    return true;
  });

  return (
    <div className="App">
      <h1>Task Management</h1>
      <div>
        <input
          type="text"
          placeholder="Add a new task"
          value={newTask}
          onChange={(e) => setNewTask(e.target.value)}
        />
        <button onClick={addTask}>Add Task</button>
      </div>
      <div>
        <button onClick={() => setFilter('all')}>All</button>
        <button onClick={() => setFilter('completed')}>Completed</button>
        <button onClick={() => setFilter('incomplete')}>Incomplete</button>
      </div>
      <ul>
        {filteredTasks.map((task) => (
          <li key={task._id}>
            <span
              style={{ textDecoration: task.completed ? 'line-through' : 'none' }}
              onClick={() => toggleTaskCompletion(task._id)}
            >
              {task.task}
            </span>
            <button onClick={() => deleteTask(task._id)}>Delete</button>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default App;

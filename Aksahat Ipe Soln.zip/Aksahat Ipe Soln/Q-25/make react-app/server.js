const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');

const app = express();
const port = process.env.PORT || 5000;

// Enable CORS
app.use(cors());

// Connect to MongoDB (replace 'mongodb://localhost/Task' with your MongoDB connection URI)
mongoose.connect('mongodb://localhost/Task', {
  useNewUrlParser: true,
  useUnifiedTopology: true,
});

// Define the task schema and model
const taskSchema = new mongoose.Schema({
  task: String,
  completed: Boolean,
});

const Task = mongoose.model('Task', taskSchema);

// Middleware to parse JSON requests
app.use(express.json());

// Define API routes
app.get('/tasks', async (req, res) => {
  try {
    const tasks = await Task.find();
    res.json(tasks);
  } catch (error) {
    res.status(500).json({ error: 'Internal server error' });
  }
});

app.post('/tasks', async (req, res) => {
  const { task } = req.body;
  try {
    const newTask = await Task.create({ task, completed: false });
    res.status(201).json(newTask);
  } catch (error) {
    res.status(500).json({ error: 'Internal server error' });
  }
});

app.put('/tasks/:id', async (req, res) => {
  const { id } = req.params;
  try {
    const task = await Task.findById(id);
    if (!task) {
      return res.status(404).json({ error: 'Task not found' });
    }
    task.completed = !task.completed;
    await task.save();
    res.json(task);
  } catch (error) {
    res.status(500).json({ error: 'Internal server error' });
  }
});

// app.delete('/tasks/:id', async (req, res) => {
//   const { id } = req.params;
//   try {
//     const task = await Task.findById(id);
//     if (!task) {
//       return res.status(404).json({ error: 'Task not found' });
//     }
//     await task.remove();
//     res.json({ message: ''})
const EventEmitter = require('events');

// Create an instance of EventEmitter
const emitter = new EventEmitter();

// Listener 1 for the common event 'myEvent'
const listener1 = () => {
  console.log('Listener 1 called');
};

// Listener 2 for the common event 'myEvent'
const listener2 = () => {
  console.log('Listener 2 called');
};

// Add both listeners to the 'myEvent' event
emitter.on('myEvent', listener1);
emitter.on('myEvent', listener2);

// Print the number of listeners for the 'myEvent' event
const listenersCount = emitter.listenerCount('myEvent');
console.log(`Number of listeners for 'myEvent': ${listenersCount}`);

// Emit the 'myEvent' event, which will trigger both listeners
emitter.emit('myEvent');

// Remove one of the listeners (listener1)
emitter.removeListener('myEvent', listener1);

// Print the number of remaining listeners for the 'myEvent' event
const remainingListenersCount = emitter.listenerCount('myEvent');
console.log(`Number of remaining listeners for 'myEvent': ${remainingListenersCount}`);

// Emit the 'myEvent' event again, which will trigger only listener2
emitter.emit('myEvent');

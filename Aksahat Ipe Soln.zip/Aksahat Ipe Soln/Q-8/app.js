const express = require('express');
const app = express();
const port = 3000;

// Sample array of product objects
const products = [
  { id: 1, name: 'Product 1', description: 'Description 1', price: 10.99 },
  { id: 2, name: 'Product 2', description: 'Description 2', price: 19.99 },
  { id: 3, name: 'Product 3', description: 'Description 3', price: 7.99 },
];

// Set up Pug as the view engine
app.set('view engine', 'pug');
app.set('views', __dirname + '/views');

// Route to display a welcome message on the homepage
app.get('/', (req, res) => {
  res.send('<h1>Welcome to the Online Store</h1>');
});

// Route to display the list of products
app.get('/products', (req, res) => {
  res.render('products', { products });
});

// Dynamic route for product details
app.get('/products/:id', (req, res) => {
  const productId = parseInt(req.params.id);
  const product = products.find((p) => p.id === productId);

  if (product) {
    res.send(`
      <h1>${product.name}</h1>
      <p>Description: ${product.description}</p>
      <p>Price: $${product.price.toFixed(2)}</p>
      <a href="/products">Back to Products</a>
    `);
  } else {
    res.status(404).render('error');
  }
});

// Custom error handler for 404 Not Found
app.use((req, res) => {
  res.status(404).render('error');
});

app.listen(port, () => {
  console.log(`Server is running on http://localhost:${port}`);
});

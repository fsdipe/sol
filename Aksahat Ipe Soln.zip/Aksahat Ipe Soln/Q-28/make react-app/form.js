import React, { useState } from 'react';
import axios from 'axios';

const Form = () => {
  const [formData, setFormData] = useState({
    city: 'Ahmedabad', // Default value
    bloodGroup: 'O+', // Default value
  });

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      // Send a POST request to your server to insert the data into the MongoDB database
      const response = await axios.post('/api/insertUser', formData);
      console.log('Data inserted:', response.data);
    } catch (error) {
      console.error('Error inserting data:', error);
    }
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };

  return (
    <div>
      <h2>User Information Form</h2>
      <form onSubmit={handleSubmit}>
        <div>
          <label htmlFor="city">City:</label>
          <select
            id="city"
            name="city"
            value={formData.city}
            onChange={handleInputChange}
          >
            <option value="Ahmedabad">Ahmedabad</option>
            <option value="Rajkot">Rajkot</option>
            <option value="Surat">Surat</option>
            <option value="Vadodara">Vadodara</option>
          </select>
        </div>
        <div>
          <label>Blood Group:</label>
          <label>
            <input
              type="radio"
              name="bloodGroup"
              value="O+"
              checked={formData.bloodGroup === 'O+'}
              onChange={handleInputChange}
            />
            O+
          </label>
          <label>
            <input
              type="radio"
              name="bloodGroup"
              value="A+"
              checked={formData.bloodGroup === 'A+'}
              onChange={handleInputChange}
            />
            A+
          </label>
          <label>
            <input
              type="radio"
              name="bloodGroup"
              value="B+"
              checked={formData.bloodGroup === 'B+'}
              onChange={handleInputChange}
            />
            B+
          </label>
          <label>
            <input
              type="radio"
              name="bloodGroup"
              value="AB+"
              checked={formData.bloodGroup === 'AB+'}
              onChange={handleInputChange}
            />
            AB+
          </label>
        </div>
        <button type="submit">Submit</button>
      </form>
    </div>
  );
};

export default Form;

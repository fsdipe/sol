const express = require('express');
const app = express();
const port = 3000;

// Sample weather data object (you can replace this with actual weather data)
const weatherData = {
  NewYork: { location: 'New York', temperature: 22, description: 'Partly Cloudy' },
  LosAngeles: { location: 'Los Angeles', temperature: 28, description: 'Sunny' },
  Chicago: { location: 'Chicago', temperature: 18, description: 'Cloudy' },
};

// Set up Pug as the view engine
app.set('view engine', 'pug');
app.set('views', __dirname + '/views');

// Route to display a welcome message on the homepage
app.get('/', (req, res) => {
  res.send('<h1>Welcome to the Weather Forecast Service</h1>');
});

// Route to display the weather forecast for a specified location
app.get('/weather', (req, res) => {
  const location = req.query.location;

  if (location && weatherData[location]) {
    const weather = weatherData[location];
    res.render('weather', { weather });
  } else {
    res.status(404).render('error', { error: 'Location not found or weather data not available.' });
  }
});

// Custom error handler for 404 Not Found
app.use((req, res) => {
  res.status(404).render('error', { error: 'Page not found.' });
});

app.listen(port, () => {
  console.log(`Server is running on http://localhost:${port}`);
});

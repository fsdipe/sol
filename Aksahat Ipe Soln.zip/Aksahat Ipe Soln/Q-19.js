import React, { useState } from 'react';

function StockDetail() {
  const [name, setName] = useState('');
  const [purchasePrice, setPurchasePrice] = useState('');
  const [purchaseQuantity, setPurchaseQuantity] = useState('');
  const [sellingPrice, setSellingPrice] = useState('');
  const [sellingQuantity, setSellingQuantity] = useState('');
  const [stocks, setStocks] = useState([]);
  
  const handleAddStock = () => {
    if (parseInt(sellingQuantity) > parseInt(purchaseQuantity)) {
      alert('Selling quantity cannot be more than purchase quantity.');
      return;
    }
    
    const stock = {
      name,
      purchasePrice: parseFloat(purchasePrice),
      purchaseQuantity: parseInt(purchaseQuantity),
      sellingPrice: parseFloat(sellingPrice),
      sellingQuantity: parseInt(sellingQuantity),
    };

    setStocks([...stocks, stock]);
    
    setName('');
    setPurchasePrice('');
    setPurchaseQuantity('');
    setSellingPrice('');
    setSellingQuantity('');
  };

  return (
    <div className="stock-detail">
      <h2>Stock Detail</h2>
      <div className="input-fields">
        <input
          type="text"
          placeholder="Name"
          value={name}
          onChange={(e) => setName(e.target.value)}
        />
        <input
          type="number"
          placeholder="Purchase Price"
          value={purchasePrice}
          onChange={(e) => setPurchasePrice(e.target.value)}
        />
        <input
          type="number"
          placeholder="Purchase Quantity"
          value={purchaseQuantity}
          onChange={(e) => setPurchaseQuantity(e.target.value)}
        />
        <input
          type="number"
          placeholder="Selling Price"
          value={sellingPrice}
          onChange={(e) => setSellingPrice(e.target.value)}
        />
        <input
          type="number"
          placeholder="Selling Quantity"
          value={sellingQuantity}
          onChange={(e) => setSellingQuantity(e.target.value)}
        />
        <button onClick={handleAddStock}>Add Stock</button>
      </div>

      <table className="stock-table">
        <thead>
          <tr>
            <th>Name</th>
            <th>Purchase Price</th>
            <th>Purchase Quantity</th>
            <th>Selling Price</th>
            <th>Selling Quantity</th>
            <th>Profit/Loss</th>
          </tr>
        </thead>
        <tbody>
          {stocks.map((stock, index) => (
            <tr key={index}>
              <td>{stock.name}</td>
              <td>{stock.purchasePrice}</td>
              <td>{stock.purchaseQuantity}</td>
              <td>{stock.sellingPrice}</td>
              <td>{stock.sellingQuantity}</td>
              <td>
                {stock.sellingQuantity < stock.purchaseQuantity
                  ? 'Invested'
                  : ((stock.sellingPrice - stock.purchasePrice) * stock.sellingQuantity).toFixed(2)}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export default StockDetail;

const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const app = express();
const port = process.env.PORT || 3000;

// MongoDB Connection
mongoose.connect('mongodb://localhost/exam', {
    useNewUrlParser: true,
    useUnifiedTopology: true,
});

// Define a schema for the Exam collection
const examSchema = new mongoose.Schema({
    name: { type: String, trim: true, maxlength: 12, required: true, uppercase: true },
    email: { type: String, required: true },
    city: { type: String, enum: ['ahmedabad', 'gandhinagar', 'vadodara'], lowercase: true },
    date: { type: Date, required: true, min: '2023-01-01', max: '2023-12-31' },
});

// Create a model for the Exam collection
const Exam = mongoose.model('Exam', examSchema);

// Middleware to parse JSON requests
app.use(bodyParser.json());

// Serve the HTML form
app.get('/', (req, res) => {
    res.sendFile(__dirname + '/form.html');
});

// Handle form submission
app.post('/submit', async (req, res) => {
    try {
        const formData = req.body;
        const newExam = new Exam(formData);
        await newExam.save();
        res.status(201).json(newExam);
    } catch (error) {
        res.status(500).json({ error: 'Internal server error' });
    }
});

// Start the server
app.listen(port, () => {
    console.log(`Server is running on port ${port}`);
});

// src/App.js
import React from 'react';
import './App.css';
import DigitalClock from './DigitalClock';

function App() {
  return (
    <div className="App">
      <DigitalClock />
    </div>
  );
}

export default App;

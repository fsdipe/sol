const express = require('express');
const app = express();
const port = 3000;

app.set('view engine', 'pug');
app.set('views', __dirname + '/views');
app.use(express.urlencoded({ extended: true }));

app.get('/', (req, res) => {
  res.render('studentForm');
});

app.post('/student', (req, res) => {
  const studentData = {
    name: req.body.name,
    email: req.body.email,
    course: req.body.course,
  };
  res.render('student', { student: studentData });
});

app.listen(port, () => {
  console.log(`Server is running on http://localhost:${port}`);
});
